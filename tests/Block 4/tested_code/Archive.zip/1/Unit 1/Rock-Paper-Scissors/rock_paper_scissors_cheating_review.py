


import random

user_action = input("Enter a choice rock, paper, scissors:) ")




if user_action == "paper" :
    print("I choose scissors. I win:p")

elif user_action == "rock" :
    print("I chose paper. I win:)")

elif user_action == "scissors":
    print("I choose rock. I win:D")


