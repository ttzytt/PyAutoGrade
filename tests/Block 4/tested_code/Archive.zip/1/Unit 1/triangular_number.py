



n = int(input("choose a positive integer. "))

i = 1
triangular_number = 0

while i <= n:
    triangular_number = triangular_number + i
    i = i + 1

print(f"The traingular number of {n} is {triangular_number}.") 
