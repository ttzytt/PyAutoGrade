





n = int(input("Choose an positive integer. "))
i = 1 
fac = 1


while i <= n:
    fac = fac * i
    i = i + 1


print(f"The factorial of {n} is {fac}")






