





Fahrenheit = int(input("What's the weather today (in F°)? "))

Celsius =round((Fahrenheit - 32)*(5/9),2)



if Fahrenheit >= 95:
          print("wow that's hot!")
elif Fahrenheit <=30:
        print("That's freezing!")


print("That's " + str(Celsius) + " C°.")


