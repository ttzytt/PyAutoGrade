




F = int(input("what the temperature today in °F?"))

if F >= 90 or F < 50:
    C = input("Did you turn on ur ac?")
    if C =="no":
        print("Poor kid. Go turn on you ac:)")
    elif C =="yes":
        print("Thank God we have technology!")

elif F <90 or F >=50:
    rain = input("Is it raining outside?")
    if rain =="no":
        print("You should play outside today:p!")
    elif rain == "yes":
        jacket = input("Do you bring an umbrella?")
        if jacket == "yes":
            print("Go out and have fun!")
        elif jacket == "no":
            print("So sad too bad.")
   




