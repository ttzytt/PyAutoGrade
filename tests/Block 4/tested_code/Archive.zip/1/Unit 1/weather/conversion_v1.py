



F = int(input("What's the weather today (in F°)? "))

C = (F - 32)*(5/9)


if F >= 95:
          print("wow that's hot!")
print("That's " + str(C) + " C°.")

