



Fahrenheit = int(input("what the temperature today in °F?"))


if Fahrenheit >= 90 or Fahrenheit < 50:
    Celsius = input("Did you turn on ur ac?")
    if Celsius =="no":
        print("Poor kid. Go turn on you ac:)")
    elif Celsius =="yes":
        print("Thank God we have technology!")

elif Fahrenheit <90 or Fahrenheit >=50:
    rain = input("Is it raining outside?") 
    if rain =="no":
        print("You should play outside today:p!")
    elif rain == "yes":
        umbrella = input("Do you bring an umbrella?") 
        if umbrella == "yes": 
            print("Go out and have fun!")
        elif umbrella == "no": 
            print("So sad too bad.")
   
