




food = input ('Food: ')

sound = input ('Sound: ')

verb_1 = input ('Verb 1: ')
verb_2 = input ('Verb 2: ')
verb_3 = input ('Verb 3: ')
verb_4 = input ('Verb 4: ')

noun_1 = input ('Noun 1: ')

animal = input ('Animal: ')

phrase = input ('Phrase: ')


adjective_1 = input ('Adjective 1: ')
adjective_2 = input ('Adjective 2: ')

famous_person = input ('Famous Person: ')
building_type = input ('Building Type: ')
household_item = input ('Household Item: ')
transportation = input ('Transportation: ')
mythical_creature = input ('Mythical Creature: ')





print ('Once upon a time, a ' + adjective_1 + ' '
       + animal + ' tried to ' + verb_1 + ' a '
       + noun_1 + '. ' + 'Just when it succeeded, '
       + famous_person + ' flew on a ' + transportation
       + ', shouting: "' + phrase + '!" '
       + 'Then, they began to ' + verb_2 + ' using a '
       + household_item + '. ' + 'Out of nowhere, a '
       + adjective_2 + ' ' + mythical_creature
       + ' appeared and started to ' + verb_3
       + ' all the ' + food + ' in the village. '
       + 'Shockingly, the ' + building_type
       + ' began to ' + verb_4 + ' while emitting '
       + sound + '. ' + 'Finally, the ' + adjective_1 + ' '
       + animal + ' began to ' + verb_4 + '.')


