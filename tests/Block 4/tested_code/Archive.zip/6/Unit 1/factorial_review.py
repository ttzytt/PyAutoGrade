





n = int(input("Give me a positive ingeter! "))

result = 1

i = n




while i > 0:
    
    result *= i
    
    i -= 1


print(f"The factorial of {n} is {result}.")

