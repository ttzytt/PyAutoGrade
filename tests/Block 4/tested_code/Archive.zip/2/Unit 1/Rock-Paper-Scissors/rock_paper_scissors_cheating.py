



player_input = input('Enter rock, paper, or scissors: ')


if player_input == 'rock':
    print('I chose paper')
    print('I won!')

elif player_input == 'paper':
    print('I chose scissors')
    print('I won!')

elif player_input == 'scissors':
    print('I chose rock')
    print('I won!')


else:
    print('Invalid choice: type rock, paper, or scissors!')

