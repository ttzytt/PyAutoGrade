



playerinput = input('Enter rock, paper, or scissors: ')


if playerinput == 'rock':
    print('I chose paper')
    print('I won!')

elif playerinput == 'paper':
    print('I chose scissors')
    print('I won!')

elif playerinput == 'scissors':
    print('I chose rock')
    print('I won!')


else:
    print('Invalid choice: type rock, paper, or scissors!')


