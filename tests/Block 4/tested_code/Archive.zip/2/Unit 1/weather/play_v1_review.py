



farenheit = float(input('What is the temperature today in °F? '))


if farenheit > 95:
    print ('You shouldnt play outside today.')
elif farenheit < 50:
    print ('You shouldnt play outside today.')
    

else:
    print ('You should play outside today.')
        

