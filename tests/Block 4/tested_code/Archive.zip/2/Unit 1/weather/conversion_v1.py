



farenheit = int(input('What is the temperature today in °F?'))


if farenheit >= 90:
        print('Wow, thats hot!')


print('Thats ' + str((farenheit - 32)/1.8) + '° celsius!')
    

