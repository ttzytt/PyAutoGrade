



farenheit = int(input('What is the temperature today in °F?'))


if farenheit >= 90:
        print('Wow, thats hot!')


if farenheit < 32:
        print('Thats freezing!')


if farenheit >= 32 and farenheit < 50:
        print('Thats pretty cold!')


print('Thats ' + str((farenheit - 32)/1.8) + '° celsius!')




 
