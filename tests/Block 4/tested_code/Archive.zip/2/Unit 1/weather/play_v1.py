



temperature = float(input('What is the temperature today in °F? '))


if temperature > 95:
    print ('You shouldnt play outside today.')
elif temperature < 50:
    print ('You shouldnt play outside today.')
    

else:
    print ('You should play outside today.')
        
