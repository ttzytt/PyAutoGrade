



human_input = input('Enter rock, scissor or paper: ')  
computer_input = ('rock' or 'paper' or 'scissor')

if human_input == 'rock':
    computer_input == print('paper')
    print('I win')
if human_input == 'paper':
    computer_input == print('scissor')
    print('I win')
if human_input == 'scissor':
    computer_input == print('rock')
    print('I win')

