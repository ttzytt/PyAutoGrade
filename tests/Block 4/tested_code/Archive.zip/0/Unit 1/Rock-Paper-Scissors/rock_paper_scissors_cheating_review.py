
make_your_choice = input('Enter rock, scissor or paper : ')  

rando = ('rock' or 'paper' or 'scissor')
if make_your_choice == 'rock':
    rando == print('paper')
    print('I win')
if make_your_choice == 'paper':
    rando == print('scissor')
    print('I win')
if make_your_choice == 'scissor':
    rando == print('rock')
    print('I win')

