


tempe = int(input('what temperature is it today (in °F)? '))
if tempe > 95 or tempe < 50:
        print('You shouldnt play outside today')
else:
        print('You should play outside today')
      
