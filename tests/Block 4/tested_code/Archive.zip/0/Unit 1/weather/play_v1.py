




temperature = int(input('What temperature is it today (in °F)? '))
if temperature > 95 or temperature < 50:
        print('You shouldnt play outside today.')
else:
        print('You should play outside today.')
      
