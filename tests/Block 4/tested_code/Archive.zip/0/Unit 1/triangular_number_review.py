


number = int(input(' Enter a number: '))
answer = ((number+1)*number)/2 
print(answer) 
             
            



