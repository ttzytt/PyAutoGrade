










weather = int(input('What is the temperature today (in °F)? '))




if weather > 95:
    print('You should not play outside today')
    



elif weather < 50:
     print('You should not play outside today')




else:
    print('You should play outside today')

