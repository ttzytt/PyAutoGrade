


Answer = input("Enter 'rock' or 'paper' or 'scissors' ")


if Answer == 'rock':
    print('I choose paper.')
    print('I win.')


if Answer == 'paper':
    print('I choose scissors.')
    print('I win.')


if Answer == 'scissors':
    print('I choose rock.')
    print('I win.')


