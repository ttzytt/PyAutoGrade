





name1 = input('a name: ')
place1 = input('a place: ')
place2 = input('another place: ')
verb = input('a verb: ')
animal = input('an animal: ')
animal2 = input('a creature: ')
adjective = input('an adjective: ')
food = input('a food: ')


story = ('Once upon a time, ' + name1 + ' woke up in the ' + place1 + ' where he has never been before. However, he began to ' + verb + ' calmly. Then, he tried to escape from ' + place1 + ' to ' +
      place2 + ' with his cute ' + animal + ' and ' + animal2 + '. In ' + place2 + ', there are ' + adjective + ' ' + food + ', so ' + name1 + ' ate the ' + food + ' in a hurry since he was really hungry.')



print(story)
