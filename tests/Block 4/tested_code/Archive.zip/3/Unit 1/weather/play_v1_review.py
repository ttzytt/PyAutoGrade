






temperature = int(input('What is the temperature today(in °F)? '))


if temperature > 95 or temperature < 50:
    print('You should not play outside today.')
else:
    print('You should play outside today.')
