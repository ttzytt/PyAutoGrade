







choice = str(input("Enter 'rock' , 'paper' or 'scissor': "))


if choice == 'rock':
    print("I choose paper")
    print('I win.')
elif choice == 'paper':
    print("I choose scissor")
    print('I win.')
else:
    print("I choose rock")
    print('I win.')
