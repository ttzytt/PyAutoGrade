




choice = str(input("Enter 'rock' , 'paper' or 'scissors': "))


if choice == 'rock':
    print("I choose paper")
    print('I win.')
elif choice == 'paper':
    print("I choose scissors")
    print('I win.')
else:
    print("I choose rock")
    print('I win.')
