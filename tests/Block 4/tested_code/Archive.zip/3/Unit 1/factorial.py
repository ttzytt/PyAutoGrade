




integer=int(input('Enter a integer '))


factor=int(1)

while integer > 1:
        factor = factor * integer
        integer = integer - 1
print('the factorial is ' + str(factor))
        
