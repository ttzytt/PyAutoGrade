def a():
    print(1)


def b():
    print(2)
