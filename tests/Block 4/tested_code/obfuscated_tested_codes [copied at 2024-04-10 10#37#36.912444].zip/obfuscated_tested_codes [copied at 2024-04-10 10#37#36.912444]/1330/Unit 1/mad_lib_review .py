











name_1 = input('a name: ')
place_1 = input('a place: ')
place_2 = input('another place: ')
verb = input('a verb: ')
anima_l = input('an animal: ')
animal_2 = input('a creature: ')
adjective = input('an adjective: ')
food = input('a food: ')


story = ('Once upon a time, ' + name_1 + ' wake up in the ' + place_1 +
         ' where he has never been before. However, he began to ' + verb
         + ' calmly. Then, he tried to escape from ' + place_1 + ' to ' +
      place_2 + ' with his cute ' + animal + ' and ' + animal_2 + '. In '
         + place_2 + ', there are ' + adjective + " " + food + ', so ' + name_1 +
         ' ate the ' + food + ' in a hurry since he was really hungry.')

print(story)
