




number = int(input('Enter a number: '))

if number/2 != round(number/2):
    print(int((1+number)*((number+1)/2)/2))
else:
    print(int((2+number)*(number/2)/2))
