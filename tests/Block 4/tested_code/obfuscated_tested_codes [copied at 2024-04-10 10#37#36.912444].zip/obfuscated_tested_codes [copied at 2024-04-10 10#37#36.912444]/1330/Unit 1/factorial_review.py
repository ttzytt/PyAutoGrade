




i=int(input('Enter a integer'))

f=int(1)

while i > 1:
        f = f * i
        i = i-1
print(f)
        
