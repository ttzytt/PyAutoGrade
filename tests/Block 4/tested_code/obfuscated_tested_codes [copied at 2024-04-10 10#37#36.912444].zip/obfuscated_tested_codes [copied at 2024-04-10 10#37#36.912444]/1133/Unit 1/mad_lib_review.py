





adjective = input('adjective:')
noun = input('noun:')
verb = input('verb in present tense:')
adverb = input('adverb:')
pluralnoun = input('plural noun:')
color = input('color:')
animal = input('animal:')
number = input('number:')




print('Once upon a time in a ' \
         + adjective + 'kindom, there lived a' + noun \
          + ' the '+ color + animal + '. ' + noun +\
          'was known throughout the land for' \
          + verb + number +pluralnoun + \
          'in one sitting, and the townsfolk were always amazed by how'\
          + adverb + noun + \
          'could do it. People came from far and wide to watch'\
          + noun + 's incredible feats of eating. It was a sight to behold')
