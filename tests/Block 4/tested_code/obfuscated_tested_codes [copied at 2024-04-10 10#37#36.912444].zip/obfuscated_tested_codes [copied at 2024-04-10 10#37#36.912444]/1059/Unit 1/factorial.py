



number_n = int(input("Please type in the number you want to be factorialized: "))




number_1 = number_n - 1




while number_1 > 1:

    number_n = number_n * number_1
    number_1 = number_1 - 1
print("The factoral of your number is " + str(number_n))

