




"""
T15
Goes through a python file and finds any function defenition in the file without a comment
on the line before and adds a line of code that says
'#R(auto): Add a comment that says what this function does!'. Assume every comment starts with
a #
"""



def main():

        
if __name__ == "__main__":
    main()
