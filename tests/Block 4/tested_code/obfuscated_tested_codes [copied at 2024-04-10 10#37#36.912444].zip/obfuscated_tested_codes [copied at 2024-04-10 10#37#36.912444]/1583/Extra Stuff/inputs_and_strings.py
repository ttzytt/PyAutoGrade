























word = input('Give me a word. ')
word_list = [*word]

word_list.reverse()
reversed_word = ''.join(word_list)

print(reversed_word)
