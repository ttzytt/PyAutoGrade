






n = int(input('Give me a number: '))


factorial_n = 1


count = 1

while count < n:
    
    count = count + 1
    factorial_n = factorial_n * count


print(factorial_n)
