




input_number = int(input('Give me a number: '))


triangular_number = 0

count = 0

while count < input_number:
    count = count + 1
    
    
    
    triangular_number = triangular_number + count


print('Triangular number #' + str(input_number) + ' is ' +
      str(triangular_number) + '.')
