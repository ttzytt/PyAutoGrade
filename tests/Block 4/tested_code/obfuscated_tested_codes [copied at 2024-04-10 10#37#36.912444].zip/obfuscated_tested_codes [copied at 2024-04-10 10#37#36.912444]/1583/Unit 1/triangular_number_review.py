





n = int(input('Give me a number: '))



triangular_n = 0


count = 0

while count < n:
    
    count = count + 1

    
    triangular_n = triangular_n + count


print(triangular_n)
