




input_number = int(input('Give me a number: '))



factorial_number = 1


count = 1

while count < input_number:
    count = count + 1
    
    
    
    factorial_number = factorial_number * count


print(str(input_number) + '! is ' + str(factorial_number) + '.')
