





place = str(input("Place: "))
name = str(input("Name: "))
noun1 = str(input("Noun 1: "))
verb = str(input("Verb: "))
adjective1 = str(input("Adjective 1: "))
noun2 = str(input("Noun 2: "))
adjective2 = str(input("Adjective 2: "))




print("Today I went to " + place + " to see my friend " + name + ". " + name \
      + " had recently bought a " + noun1 + " to " + verb \
      + " their cat with. I watched them do it at " + place + ", and now I am very very " \
      + adjective1 + ". " + name + " has inspired me. Now I will obtain a " \
      + noun2 + " and get up to some " + adjective2 + " business.")
