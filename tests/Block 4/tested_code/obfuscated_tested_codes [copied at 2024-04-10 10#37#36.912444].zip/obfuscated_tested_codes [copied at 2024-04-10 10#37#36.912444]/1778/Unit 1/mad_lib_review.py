



name=input('Name:')
number=input('Number Greater Than 1:')
place=input('Place:')
food=input('Food(Plural):')
animal=input('Animal(Plural):')
place2=input('Place 2:')
adjective=input('Adjective: ')


print( 'There exists a sport named ' + name + '.' + ' In this sport, ' + number + ' teams compete to score the most points. Teams can score points by running into a ' + place + ' with ' + food + '. ' + animal + ' play a key part by dancing in a ' + place2 + '. Many describe this game as ' + adjective + '.' ) 


