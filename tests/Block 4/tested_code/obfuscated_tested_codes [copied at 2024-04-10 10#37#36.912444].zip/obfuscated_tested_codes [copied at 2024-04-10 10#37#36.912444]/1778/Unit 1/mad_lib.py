




"""
Teacher comments:
• Good try with the comments. See suggestions below.
• Comments must start with spaces.
• Good variable names except you need _ between words (numbers are words too).
• Lines of code must fit on a half-screen (shouldn't go past column 80.)

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""







name = input('Name:')  
number = input('Number Greater Than 1:')
place = input('Place:')
food = input('Food(Plural):')
animal_l = input('Animal(Plural):')
place_2 = input('Place 2:')  
adjective = input('Adjective: ')







print( 'There exists a sport named ' + name + '.' + ' In this sport, '\
        + number + ' teams compete to score the most points.'\
        + ' Teams can score points by running into a ' +  place + ' with ' \
        + food + '. ' + animal_l + ' play a key part by dancing in a '\
        + place_2 + '. Many describe this game as ' + adjective + '.' ) 

