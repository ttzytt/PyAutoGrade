




num = int(input("Enter a positive integer: "))


count = 1



final_sum = 0



while count <= num:
    final_sum = final_sum + count
    count = count + 1







    
print("The " + str(num) + "th triangular number is " + str(final_sum))
