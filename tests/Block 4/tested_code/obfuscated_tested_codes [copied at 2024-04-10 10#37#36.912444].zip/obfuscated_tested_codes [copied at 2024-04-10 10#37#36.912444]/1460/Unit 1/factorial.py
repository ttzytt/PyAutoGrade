





num = int(input('Enter a positive integer: '))


count = 1



final_product = 1



while count <= num:
    final_product = final_product * count
    count = count + 1







    
print(str(num) + '! is equal to ' + str(final_product))
