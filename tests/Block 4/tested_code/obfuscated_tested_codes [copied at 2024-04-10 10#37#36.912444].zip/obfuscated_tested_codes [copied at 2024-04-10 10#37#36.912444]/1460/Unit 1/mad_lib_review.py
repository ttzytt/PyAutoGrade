






pluralNoun1 = input("noun, plural 1: ")
adjective = input("adjective: ")
place1 = input("place 1: ")
place2 = input("place 2: ")
landscapeFeature = input("landscape feature: ")
number = input("number: ")
pluralNoun2 = input("noun, plural 2: ")
pluralNoun3 = input("noun, plural 3: ")
verb = input("verb: ")
store = input("store (i.e. mcdonalds): ")
adverb = input("adverb: ")



madlibs = (

"A long long time ago, there existed a group of " + pluralNoun1 + ". " +
"These " + pluralNoun1 + " were rather " + adjective +
" and traveled from " + place1 + " to " + place2 + ". " +
"However, when they were crossing a " + landscapeFeature +
", a North Carolinian troll stopped them in their paths." +
"\"Fee Fi Fo Fum. If you wanna cross I\'ma need sum,\" it said. " +
"Give me " + number + " " + pluralNoun2 + " and a stack of " + pluralNoun3 + ". " +
"The " + pluralNoun1 + " then " + adverb + " hoverboared to the nearest " + store +
" and " + verb + " the cashier."

)


print(madlibs)







