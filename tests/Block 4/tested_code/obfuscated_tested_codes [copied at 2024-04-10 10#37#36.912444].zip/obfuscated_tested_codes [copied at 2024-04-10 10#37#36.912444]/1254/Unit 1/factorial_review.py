


n = int(input('Please enter a number: '))

count = 0

factorial = 1

while count < n:
    
    count = count + 1
    factorial = factorial * count
    
print("n! would be: " + str(factorial))


'''R
What is this program supposed to do, I cant tell until I actually run it.
Also, spaces between the lines would be great.  Just add 'print()' after each line to make it easier to read.
Other than this, I don't see much problem.
'''
