


noun1 = input('Choose a noun: ')

noun2 = input('Choose another one!: ')

print("Let's change things up a bit :)")

verb = input("This time, choose a verb that ends in 'ing':")

adj1 = input('Adjective? ')

adj1 = input('You can do better... choose something else :( ')

adj2 = input('Another one: ')

emo = input('How are feeling today? ')

print('Great job! Now, enjoy a story...')

print(noun1 + ' loves ' + verb + ' at Texas Outback Steakhouse.')

print('Ever since ' + verb + ' at Outback Steakhouse, ' + noun1 + ' grew a ' + adj1 + ', ' + adj2 + ' beard.')

print('Unfortunately, because of ' + noun1 + "'s" + " violation of the customers' " + noun2 + ' code, he was fired, to his ' + emo)


