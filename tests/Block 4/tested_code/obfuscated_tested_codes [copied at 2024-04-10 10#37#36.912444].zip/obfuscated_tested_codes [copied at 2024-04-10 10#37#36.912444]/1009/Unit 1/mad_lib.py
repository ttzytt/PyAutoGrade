

"""
Teacher comments:
• Most important: Your reviewer gave helpful advice, and you
ignored it. This will always lose you points. And more importantly,
you are missing the opportunity to learn from your mistakes and
from your classmates.
• Variable names mostly are ok.
• Needs comments!!!
• Comments (even the ones above) must start with spaces.
• Things your reviewer said still apply, since they weren't fixed.

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""
person_1 = input("Enter the name of a person: ")


noun_2 = input("write a sport: ")
place = input("write a place :  ")
animal = input("write an animal: ")
verb = input("write a verb: ")



sentence = "Once upon a time, there was a guy called " + noun_1 + ". "+ noun_1 + " outgoing and loves playing " + noun_2 +". " + "Usually "+ noun_1+ " takes the pet, " + animal +" to go to the "
+ place +" for " + verb + "."
print(sentence)
