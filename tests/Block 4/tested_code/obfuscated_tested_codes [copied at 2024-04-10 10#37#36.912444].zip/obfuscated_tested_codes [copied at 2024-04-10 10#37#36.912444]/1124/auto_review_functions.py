



def comments_for_functions(in_file, out_file)
    
