

"""
Teacher comments:
• name1 must be name_1. Same with other variables
• Your code needs blank lines between sections to make it readable
• Operators, such as "=", need spaces around them.

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""








name1=input('Name 1:')
species=input('Species:')
name2=input('Name 2:')
noun1=input('Noun 1(plural):')
verb1=input('Verb 1:')

print ('Once upon a time in the planet of ' + name1 + ', there lived a ' + species
       + ' named ' + name2 + ' who was very famous for their ' + noun1 +
       '. Every citizen of ' + name1 + ' knew about their ' + noun1 +
       ' and loved to watch them ' + verb1 + '.')
