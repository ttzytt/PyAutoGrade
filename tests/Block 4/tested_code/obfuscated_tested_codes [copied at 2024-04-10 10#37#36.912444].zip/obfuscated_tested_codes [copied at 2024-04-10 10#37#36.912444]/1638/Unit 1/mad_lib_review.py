







scientist_name = input("Enter a Scientist's Name: ")
adjective = input("Enter an Adjective: ")
plural_noun = input("Enter a Plural Noun: ")
verb = input("Enter a Verb: ")
noun = input("Enter a Noun: ")
liquid = input("Enter a Liquid: ")
type_of_container = input("Enter a Type of Container: ")
number = input("Enter a Number: ")
solid_substance = input("Enter a Solid Substance: ")
object_ = input("Enter an Object: ")  
heat_source = input("Enter a Heat Source: ")





madlib_story = f"""One day, {scientist_name} was working in their {adjective} laboratory, mixing various {plural_noun} in test tubes and Erlenmeyer flasks. 
Suddenly, they had an idea to create a new substance that could {verb} {noun}.

First, they took 50 mL of {liquid} and poured it into a {type_of_container}. Next, they added {number} grams of {solid_substance} and stirred the mixture with a {object_}.
To make the reaction faster, they heated the solution using a {heat_source}."""


print(madlib_story)



