





integer = input(' Tell me a random integer ')
integer = int(integer)
number = 1
triangle_number = 0


while number <= integer:
    triangle_number = triangle_number + number
    number = number + 1





print(' The triangular number is ' + str(triangle_number))
