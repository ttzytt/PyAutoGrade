


def write_diamond_pattern(out_file, width)



def last_name_first(in_file, out_file)



