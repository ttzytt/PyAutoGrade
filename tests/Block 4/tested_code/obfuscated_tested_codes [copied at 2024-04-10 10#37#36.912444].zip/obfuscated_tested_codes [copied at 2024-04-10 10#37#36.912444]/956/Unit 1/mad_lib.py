

"""
Teacher comments:
• Variable names must follow proper style. ball_game is good. Use noun_1 instead
of noun1
• Good formatting overall.
• All comments (above and below) should start with a space.
• Good try with the comments, but these will need to get better. See my\
suggestions below.

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""













ball_game = input('write a ball game ')
noun_1 = input('write a noun ')
number = input('write a number ')
noun_2 = input('write a noun ')
adjective = input('write an adjective ')




print('There is a ' + ball_game + ' game every Saturday in the town. There is a team called the ' + noun_1 + '. ' + 
      'This team is very strong. They can win ' + number + ' more points than the other teams per game. ' + 
      'They are eating ' + noun_2 +' before the game. Although it is wierd, it can make them feel ' + adjective + '. ' + 
      'This feeling can help them win the game. So they always win the games.')
