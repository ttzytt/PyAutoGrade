



n = input('write a number: ')



i = 1
product = 0


while i <= int(n):
    product = i + product
    i = i + 1


print(product)
