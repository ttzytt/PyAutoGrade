



"""
Sample output for v2:

What is the temperature today (in °F)? 95
Wow that's hot.
That's 35 °C.

What temperature is it today (in °F)? 30
Wow that's freezing.
Thats -1 °C.

What temperature is it today (in °F)? 40
Wow that's so cold.
That's 4 °C.

What temperature is it today (in °F)? 60
That's normal
That's 15 °C.

"""







"""
Sample output for v4:

What is the temperature today (in °F)? 60
Is it raining? Yes
Do you have a jacket? No
You shouldn’t play outside today.


What is the temperature today (in °F)? 60
Is it raining? Yes
Do you have a jacket? Yes
You should play outside today.

What is the temperature today (in °F)? 60
Is it raining? No
You should play outside today.



Fill in the sample output for the other cases here.
There are 4 cases total (play or don't play, with or without jacket
    question).
Make sure to test your code for each case in your chart!
.
.
.
"""
