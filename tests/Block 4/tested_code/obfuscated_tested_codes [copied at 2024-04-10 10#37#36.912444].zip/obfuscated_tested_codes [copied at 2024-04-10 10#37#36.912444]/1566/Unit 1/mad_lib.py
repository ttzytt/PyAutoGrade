

"""
Teacher comments:
• Code review is missing!!!
• Variable names have been fixed
• Good formatting, except you need blank lines between the Written by / Reviewed
by part above and the where your actual code starts
• Some lines are too long.
• The last part of your code doesn't look right. It should just print.
• Comments should always start with spaces.
• Good comments

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""



adjective_1 = input('adjective 1:')
adjective_2 = input('adjective 2:')
adjective_3 =input('adjective 3:')
place_1 = input('place 1:')
place_2 = input('place 2:')
body_1 = input('body part 1:')
body_2 = input('body part 2:')
body_3 = input('body part 3:')
noun_1 = input('noun 1:')






Every = input('Every year, you visit the doctor.' + 'It is a very' + ' ' + adjective_1 + ' ' + 'vist.') 
The = input('The visit is usually in' + ' ' + place_1 + '.')
Doc = input('The doctor is a' + ' ' + adjective_2 + ' ' + 'person.')
Gret = input('They always greet me with a' + ' ' + adjective_3 + ' ' + 'smile.')
ex = input('They usually examine your' + ' ' + body_1 + ',' + body_2 + ' ' + 'and' + ' ' + body_3 + '.')
give = input('Afterwards they will give you a' + ' ' + noun_1 + ' ' + 'and send you on our way' + ' ' + place_2 + '.')
