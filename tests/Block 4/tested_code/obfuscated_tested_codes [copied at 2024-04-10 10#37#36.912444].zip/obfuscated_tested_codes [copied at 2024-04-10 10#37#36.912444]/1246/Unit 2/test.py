def print_a():
    return 'a'

print(print_a() + "a")
