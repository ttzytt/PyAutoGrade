first = input('First name:')
last = input('Last name:')
middle = input('Middle name:')
print('Hi my name is' + last + ',' + middle + last + ',' + first + middle + last)
