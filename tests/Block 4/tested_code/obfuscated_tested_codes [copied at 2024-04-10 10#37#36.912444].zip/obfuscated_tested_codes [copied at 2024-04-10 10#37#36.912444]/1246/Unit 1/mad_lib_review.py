






name_1 = input('name 1: ')
name_2 = input('name 2: ')
name_3 = input('name 3: ')
food_1 = input('food 1 (plural): ')
place_1 = input('place 1: ')
verb_ing = input('verb with -ing: ')

noun_3 = input('noun 3 (plural): ')
noun_1 = input('noun 1 (plural): ')
noun_2 = input('noun 2 (plural): ')



print( name_1 + ' loves eating ' + food_1 + '. One day, ' + name_1 + ' decided to make his own '
+ food_1 + '. ' + name_1 +' realized they needed ' + noun_2 + ' to make ' + food_1 + '. In the end, '
+ name_1 + ' tried calling ' + name_2 + ', but they were ' + verb_ing + ' ' + noun_3 + '. ' + name_1
+ ' gave up trying to make ' + food_1 + ', and went to the ' + place_1 + ' that sells ' + food_1 + ', called ' + name_3 + "'s " + place_1 + '.')
