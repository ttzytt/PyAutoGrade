

"""
Teacher comments:
• Your code needs more comments (see below).
• Good variable names.
• Some of your lines are too long. (Standard advice is to not go past column 80.)
• Otherwise most formatting looks good (see my comments near the end).

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""





print('spaces are included, do not type spaces, all lowercase')


name_1 = input('name 1: ')
name_2 = input('name 2: ')
name_3 = input('name 3: ')

food_1 = input('food 1(plural): ')
place_1 = input('place 1: ')

verb_ing = input('verb with -ing: ')

noun_1 = input('noun 1 (plural): ')
noun_2 = input('noun 2 (plural): ')
noun_3 = input('noun 3 (plural): ')


print( name_1 + ' loves eating ' + food_1 + '. One day, ' + name_1 + ' decided to make his own '

+ food_1 + '. \n' + name_1 +' realized they needed ' + noun_2 + ' to make ' + food_1 + '. In the end, '




+ name_1 + ' tried calling ' + name_2 + ', but they were ' + verb_ing + ' ' + noun_3 + '. \n' + name_1
+ ' gave up trying to make ' + food_1 + ', and went to the ' + place_1 + ' that sells ' + food_1 + ', called ' + name_3 + "'s " + place_1 + '.')

