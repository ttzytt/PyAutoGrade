


object = input('Object: ')
place = input('Place: ')
verb = input('Verb in past tense: ')
food = input('Food: ')
animal = input('Animal: ')
name = input('Name: ')
adjective = input('Adjective: ')

print('Once upon a time, a ' + object + ' was shipped to ' + place + ', but was last in transit. Later, a boy named ' + name + ' found the ' + object + ' while he was eating ' + food + ' with his ' + adjective + ' pet ' +animal + '. The boy then ' + verb + ' to his house, and showed his parents the ' + object + '.')


