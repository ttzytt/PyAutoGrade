

"""
Teacher comments:
• This file shouldn't have reviewer comments in it when you're done.
• Variable names must follow proper style. verb_1, not verb1.
• Needs comments!!!
• No spaces after function names, "print(", not "print (".
"input(", not "input ("

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""



name = input ('enter a name: ')




adjective1 = input ('enter a adjective: ')  
adjective2 = input ('enter a adjective again: ')
verb1  = input ('enter a verb: ')
verb2 = input ('enter another verb: ')
place = input ('enter a place: ') 
adjective3 = input ('enter yet another adjective: ')
city = input ('enter a city: ')
animal1  = input ('enter an animal: ')
animal2 = input ('last but not least enter an animal: ')







print ('one day a ' + animal1 + ' ' + 'named ' + name + ' ' + 'was walking down the hill to the ' + adjective1
       + ' ' + city + ' ' + '. ' + 'it was just an ordianry day until a ' + animal2 + ' ' + verb1 + ' ' + name + '. '
       + 'but the ' + animal2 + ' ' + 'did not even apologize. that messed up ' + name + 's' + ' '  +
       'daily routine because ' + name + ' ' + 'might be late. now ' + name + ' ' + 'will not have time to go '
       + 'to the ' + place + ' ' + 'to ' + verb2 + ' ' + '. ' + name + ' ' + 'was feeling ' + adjective2 + ' ' + '. ' +
       'but when ' + name + ' ' + 'got to ' + place + ' ' + ', ' + name + ' ' + 'was on time' + '. now ' + name + 's '
       + adjective3 + ' ' + 'day has returned to plain old ordinary.')
    
