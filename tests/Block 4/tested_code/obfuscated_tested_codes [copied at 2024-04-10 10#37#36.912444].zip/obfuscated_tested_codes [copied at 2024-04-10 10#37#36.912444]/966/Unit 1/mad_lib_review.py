




name = ''



adjective = ''
adjectives = ''
verb  = ''
verbs = ''
place = ''
adjectivess = ''
city = ''
animal  = ''
animals = ''



print ('one day a ' + animal + ' ' + 'named ' + name + ' ' + 'was walking down the hill to the ' + adjective
       + ' ' + city + ' ' + '. ' + 'it was just an ordianry day until a ' + animals + ' ' + verb + ' ' + name + '. '
       + 'but the ' + animals + ' ' + 'did not even apologize. that messed up ' + name + 's' + ' '  +
       'daily routine because ' + name + ' ' + 'might be late. now ' + name + ' ' + 'will not have time to go '
       + 'to the ' + place + ' ' + 'to ' + verbs + ' ' + '. ' + name + ' ' + 'was feeling ' + adjectives + ' ' + '. ' +
       'but when ' + name + ' ' + 'got to ' + place + ' ' + ', ' + name + ' ' + 'was on time' + '. now ' + name + 's '
       + adjectivess + ' ' + 'day has returned to plain old ordinary.')
    
