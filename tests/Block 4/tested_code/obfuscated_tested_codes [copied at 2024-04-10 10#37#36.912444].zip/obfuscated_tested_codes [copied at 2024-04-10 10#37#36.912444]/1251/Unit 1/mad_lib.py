


"""
Teacher comments:
• Variable names must follow proper style. Multiple issues with these.
• Has comments. See my suggestions below.
• Prompts are strange.
• No spaces after function names – "print(" not "print (",
"input(" not "input ("

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""





noun_1 = input('Noun1: ')  
noun_2 = input('Noun2: ')
noun_3 = input('Noun3: ')
noun_4 = input('Noun4: ')
adverb = input('Adverb: ')  
adjective = input('Adjective: ')
verb_1 = input('Verb1: ')
verb_2 = input('Verb2: ')
verb_3 = input('Verb-ing: ')








print('Eric is a ' + noun_1 + ' in prisms and he is a great video game player.He can win many ' + noun_2 + 
       '. One day, he scored a lot in a game' + ' and he wanted a cup of ' + noun_3 + ' to drink to celebrate.'+
       'Unfortunenately, when he open the ' + noun_4 + ', he ' + adverb + ' found that it was run out. He felt ' + adjective + ' and he ' + verb_1
       + ' at the play ground to adjust his emotion. He got tired soon and ' + verb_2 +' in the bathroom. At last he went back to the dorm'
       ' for '+ verb_3 +'.')

