




n1 = input ('Noun1: ')
n2 = input ('Noun2: ')
n3 = input ('Noun3: ')
n4 = input ('Noun4: ')
adv = input ('Adverb: ')
adj = input ('Adjective: ')
v1 = input ('Verb1: ')
v2 = input ('Verb2: ')
v3 = input ('Verb-ing: ')




print ('Eric is a ' + n1 + ' in prisms and he is a great video game player. He can win many ' + n2 + '. One day, he scored a lot in a game' + ' and he wanted a cup of ' + n3 + ' to drink to celebrate. Unfortunenately, when he open the ' + n4 + ', he ' + adv + ' found that it was run out. He felt ' + adj + ' and he ' + v1 + ' at the play ground to adjust his emotion. He got tired soon and ' + v2 +' in the bathroom. At last he went back to the dorm for '+ v3)

