
"""
Teacher comments:
• Should have a reviewer listed (even in this file)
• Variable names must follow proper style.
part of a sentence – maybe "paragraph" or better yet, "story"
• All comments (the ones above and below) must start with a space.
• Put blank line between "Written by" part and your code.
• Some formatting issues (see below.)

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""
print ('Please enter all words without any spaces')




Name1 = input ('Name 1:')  
Name2 = input ('Name 2:')  

Time1 = input ('Time 1 (example 2:00 PM):')
Time2 = input ('Time 2 (example 7:00 AM):')
Noun1 = input ('Noun 1 (Single):')
Verb1 = input ('Verb 1:')
Verb2 = input ('Verb 2:')
Game1 = input ('Game 1:')
Food1 = input ('Food 1:')
Food2 = input ('Food 2:')
Book1 = input ('Name of a book:')
Book2 = input ('Name of a book:')



print ('A day in the life of ' + Name1 + ' consists of waking up at ' + Time1 + '.')
print (Name1 + ' then goes to the school ' + Noun1 + '.')
print (Name1 + ' loves to ' + Verb1 + ' and ' + Verb2 + '.')
print (Name1 + ' then goes to the cafetiera with their friend ' + Name2 + '.')
print ('Then they get their favorite foods ' + Food1 + ' and ' + Food2 + '.')
print ('After eating, they decide to go to ' + Name1 + " 's house.")
print ('They relax by playing ' + Game1 + ' and reading their favorite books ' + Book1 + ' and ' + Book2 + '.')
print (Name1 + ' looks at the clock and sees that it is already ' + Time2 + '.')
print (Name2 + ' decides to go home and ' + Name1 + ' goes to bed after a very busy day.') 






    



