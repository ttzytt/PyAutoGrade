


number = int(input("Write a random number 'n': ")) 

multi = 1 
while number > 1: 
    multi = multi * number
    number = number - 1 

print('The value of n! is ' + str(multi)) 




