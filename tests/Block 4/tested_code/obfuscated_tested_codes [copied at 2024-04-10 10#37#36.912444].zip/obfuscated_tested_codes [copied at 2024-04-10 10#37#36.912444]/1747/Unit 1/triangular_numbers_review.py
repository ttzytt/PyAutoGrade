


number = int(input("Write a random number 'n': ")) 

add = 0 
while number > 0: 
    add = add + number
    number = number - 1 

print('The value of n! is ' + str(add)) 



