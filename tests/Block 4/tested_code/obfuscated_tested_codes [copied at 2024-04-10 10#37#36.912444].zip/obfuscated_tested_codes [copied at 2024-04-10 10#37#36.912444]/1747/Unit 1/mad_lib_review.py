






name_1 = input('Name 1: ')
name_2 = input('Name 2: ')
place_1 = input('Place 1: ')
place_2 = input('Place 2: ')
food = input('Food: ')
adjective = input('Adjective: ')
noun = input('Noun: ')




phrase = ('Once upon a time, a child called ' + name_1
          + ' went to ' + place_1 + ' all by him/herself'
          + ', for ' + name_1 + ' wanted to explore ' +
          'the world. ' + name_1 + ', however, went to '
          + place_2 + ' first, met ' + name_2 + ' there' 
          + ' because they were at the same ' + food +
          ' restaurant. At that place, ' + name_1
          + ' and ' + name_2 + ' spent ' + adjective
          + ' days together, finding out they'
          + ' love ' + noun + ' in common.')



print(phrase)
