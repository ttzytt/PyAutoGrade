






# Prompts for user input, ensuring spaces after colons.
adjective = input('adjective: ')

noun = input('noun: ')

verb = input('verb in present tense: ')

adverb = input('adverb: ')

plural_noun = input('plural_noun: ')# Changed variable name to 'plural_noun'.

color = input('color: ')

animal = input('animal: ')

number = input('number: ')

# Generate and print the story with appropriate spaces.
print('Once upon a time in a ' +
      adjective + ' kingdom, there lived a ' + noun +
      ' the ' + color + ' ' + animal + '. ' + noun +
      ' was known throughout the land for ' + verb + ' ' + number +
      ' ' + plural_noun + ' in one sitting, and the townsfolk were always amazed by how ' +
      adverb + ' ' + noun + ' could do it. People came from far and wide to watch ' +
      noun + "'s incredible feats of eating. It was a sight to behold.")









