x = 1
points = []
y = x^2
for x_val in range(-1000, 1000, 1):
    x_val /= 100
    points.append((x_val, x_val**2))
    
