





def largest_element(numbers):
    numbers.sort() 
    largest = sorted_list[-1]  
    return largest  

def alternate_sum(numbers):
  even_numbers = numbers[0:(len(numbers)):2]
  sum_numbers = sum(even_numbers)

def rotate_right(numbers):
    my_list = my_list[-1:] + my_list[:-1] if len(my_list) > 1 else my_list

def deal_3_hands(numbers):
