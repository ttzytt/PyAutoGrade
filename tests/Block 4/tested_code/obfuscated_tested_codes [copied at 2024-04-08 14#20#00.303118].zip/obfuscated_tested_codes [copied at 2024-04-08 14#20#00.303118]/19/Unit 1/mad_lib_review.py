


none = input('give me a noun:')
aone = input('give me an animal:')
ntwo = input('give me a second noun:')
nthree = input('give me a third noun:')
pone = input ('give me a place:')
nfour = input ('give me a fourth noun:')

madlib = ('Once upon a time, there was a '+ none + ' class. It’s mainly about teaching ' + aone + ' to use ' + ntwo + ' and '+nthree+ '. Student’s would have the class on '+pone+ ', it’s a room with bunch of ' + nfour)


print(madlib)

ask = input ('do you want to have a another one? Choose Yes or No :')
if (ask == 'Yes'):

    onen = input('give me a name:')
    fiven = input('give me a noun:')
    onev = input('give me a verb:')
    sixn = input('give me a noun:')
    onea = input('give me a adj:')
    twoa = input('give me an animal:')

    madlibtwo = ('The was a guy named '+ onen +', he has got his '+fiven+' stolen because he forget to '+onev+ ' when he put it in the shared '+sixn+'. He is so '+onea+' about it that he told '+twoa+ ' about it.')
    print(madlibtwo)

input('rate this from 1-5: ')

    
