def comments_for_functions(in_file, out_file):
    lines = in_file_name.read()
    print(lines)
    line = lines.split()
    i = 0
    

with (open('Text files/T15_read.py', 'r') as in_file_name,
        open('Text files/T15_write.py', 'w') as out_file_name):
