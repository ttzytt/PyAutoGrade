


number = int(input('Please enter a integer greater than 0: '))
factorial = 1

while number > 0:
    factorial = factorial * number
    number = number - 1
    
print(factorial)




