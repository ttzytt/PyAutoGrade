



def comments_for_functions(in_file, out_file):
    list_of_lines = my_file.readlines()
    for line in list_of_lines:
        if '#R' in list_of_lines:
            
        
