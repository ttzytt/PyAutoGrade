


n = int(input('Please enter a number: '))

count = 0

factorial = 1

while count < n:
    
    count = count + 1
    factorial = factorial * count
    
print("n! would be: " + str(factorial))



