







adjective_1 = input('Write an adjective') 
                                                                          
name = input('Write a name')
animal = input('Write an animal ')
distance = input('Write a distance')
restaurant = input('Write the name of a restaurant or fast food chain')
food_1 = input('Write a food item')
food_2 = input('Write a different food item')
transportation = input('Write a type of transportation')


print ('One' + adjective_1 + ' day,' + name + ' decided to go on a walk with her pet ' + animal + 
       '. ' + name + ' walked for' + distance + ' before getting hungy. She then walked to the' 
       ' nearest' + restaurant + ' and ate some' + food_1 + '. She fed her ' + animal + ' some' + 
       food_2 + '. ' + name + ' then took a ' + transportation + ' home.')
       
