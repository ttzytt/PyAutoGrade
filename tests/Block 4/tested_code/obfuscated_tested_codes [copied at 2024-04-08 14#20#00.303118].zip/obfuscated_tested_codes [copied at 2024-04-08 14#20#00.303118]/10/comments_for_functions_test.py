




def alphabet_soup():
    x = 1
    for i in range(1)
    x += 1


def hi():
    x = 1
    y = 2

def howdy_partner():
    x = 1
    y = x+1


def function():
    f = 1
    u = 2
    n = 3
    c = 4
    t = 5
    i = 6
    o = 7
    n = 8
