


import random
random.seed()





def comments_for_functions(in_file, out_file):
    
    list_of_lines = in_file.readlines()
    
    n = 0
    while n < len(list_of_lines):
        
        if list_of_lines[n][:4] == 'def ':
            
            if (list_of_lines[n-1][0] != '#' and
                list_of_lines[n-1][0] != "            
    new_string = ''
    for i in range(len(list_of_lines)):
        new_string += str(list_of_lines[i])
    return new_string
    ------------------------TESTS-------------------------
def main():
    
    # T15
    print('T15 finished')
    input_file = 'file_writing.py'
    output_file = 'Unit 3 Test/T15.py'
    with (open(input_file, 'r') as my_file1,
          open(output_file, 'w') as my_file2):
        comments = comments_for_functions(my_file1, my_file2)
        my_file2.write(str(comments))
    print()
        
    # T16
    print('T16 finished')
    input_file = 'file_writing.py'
    output_file = 'Unit 3 Test/T16.py'
    with (open(input_file, 'r') as my_file1,
          open(output_file, 'w') as my_file2):
        blanks = blank_lines_around_functions(my_file1, my_file2)
        my_file2.write(str(blanks))
    print()

    # T17
    print('T17 finished')
    input_file = 'file_writing.py'
    output_file = 'Unit 3 Test/T17.py'
    with (open(input_file, 'r') as my_file1,
          open(output_file, 'w') as my_file2):
        breaks = break_up_long_lines(my_file1, my_file2)
        my_file2.write(str(breaks))
'''

print('T15 finished')
input_file = 'file_writing.py'
output_file = 'Unit 3 Test/T15.py'
with (open(input_file, 'r') as my_file1,
        open(output_file, 'w') as my_file2):
    comments = comments_for_functions(my_file1, my_file2)
    my_file2.write(str(comments))
print()
        

print('T16 finished')
input_file = 'file_writing.py'
output_file = 'Unit 3 Test/T16.py'
with (open(input_file, 'r') as my_file1,
        open(output_file, 'w') as my_file2):
    blanks = blank_lines_around_functions(my_file1, my_file2)
    my_file2.write(str(blanks))
print()


print('T17 finished')
input_file = 'file_writing.py'
output_file = 'Unit 3 Test/T17.py'
with (open(input_file, 'r') as my_file1,
        open(output_file, 'w') as my_file2):
    breaks = break_up_long_lines(my_file1, my_file2)
    my_file2.write(str(breaks))
    

