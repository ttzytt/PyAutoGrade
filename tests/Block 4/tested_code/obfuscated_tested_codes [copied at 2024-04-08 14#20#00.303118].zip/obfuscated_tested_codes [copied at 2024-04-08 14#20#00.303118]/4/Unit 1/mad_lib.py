




time = input ('time: ')
name = input('name: ')
verb = input('verb: ')
place = input('place: ')
adv = input('adv: ')  
print('today '+name+' woke up at '+time+' and '+adv+' found that he is late'
      ', he '+verb+' to the '+place)

