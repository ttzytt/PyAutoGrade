




import random
random.seed()
m = random.randint(0,1)
n = random.randint(0,2)
x = [' ',' don\'t ']
y = ['Python','Java','C++']
print('Do you like PRISMS?')
print('I' + x[m] + 'like PRISMS')
print()
print('What\'s your favorite programming system?')
print('My favorite programming system is ' + y[n])



