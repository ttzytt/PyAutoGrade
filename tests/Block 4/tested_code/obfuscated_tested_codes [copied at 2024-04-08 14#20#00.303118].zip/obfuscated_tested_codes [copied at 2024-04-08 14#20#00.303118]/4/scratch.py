



for n in range(9,1,-2):
    print(n)
