


name1 = input ('Welcome to Mayas Mad Lib. Enter a name:')
name2 = input ('Enter another name:')
place = input ('Enter a place:')
animal = input ('Enter an animal:')
proffession = input ('Enter a proffession:')
name3 = input ('Enter another name:')
thing = input ('Lastly, name an object:')



print('One day, ' + name1 + ' and ' + name2 + ' decided to go on a month long vacation to ' + place +
      ', leaving their pet ' + animal + ' with their good friend and ' + proffession + '; ' + name3 +
      '. ' + name1 + ' and ' + name2 +'s ' + animal + ' did not like the ' + proffession +
      ' one bit, and decided to break ' + name3 + 's favorite ' + thing + '!!!')








