



n = int(input('Enter a number: '))

count = 0

triangular_number = 0



while count < n:
    count = count + 1
    triangular_number = triangular_number + count


print('The nth triangle number would be ' + str(triangular_number))


