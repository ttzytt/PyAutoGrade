





n = int(input('Type in a number: '))
n_factorial = 1
countdown = 1
while countdown <= n:
    n_factorial = n_factorial * countdown
    countdown = countdown +1
print('The value of n! equals ' + str(n_factorial) +'.')
 
