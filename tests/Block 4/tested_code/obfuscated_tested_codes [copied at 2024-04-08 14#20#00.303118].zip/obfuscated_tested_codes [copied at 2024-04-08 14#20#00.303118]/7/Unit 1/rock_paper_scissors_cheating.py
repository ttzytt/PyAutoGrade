




user_choice = input("Enter 'rock' or 'paper' or 'scissors': ")



if user_choice == 'rock':
    print('I chose paper I win haha loser')
       
elif user_choice == 'paper':
    print('I chose scissors I win haha loser.')

elif user_choice == 'scissors':
    print('I chose rock I win haha loser.')

   
    


    
       





