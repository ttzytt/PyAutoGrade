

import random

random.seed()


def find_winner(num_wereolves, num_villager):


    while num_werewolves > 0 and num_villager != num_werewolves and num_villager > 0:



        num_total = num_werewolves + num_villager

        if random.randint(0, num_total) < 4:
            pass

        
        return num_werewolves = num_villager

        if num_werewolves


        
        num_villager = num_villager - 1






        
        


        



        


        
        




        






        
        
       
