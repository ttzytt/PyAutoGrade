




noun_1 = input("write a person: ")

noun_2 = input("write a sport: ")
place = input("write a place :  ")
animal = input("write an animal: ")
verb = input("write a verb: ")

sentence = "Once upon a time, there was a guy called " + noun_1 + ". "+ noun_1 + " outgoing and loves playing " + noun_2 \
           +". " + "Usually "+ noun_1+ " takes the pet, " + animal +" to go to the "\
           + place +" and " + verb + "."


print(sentence)

