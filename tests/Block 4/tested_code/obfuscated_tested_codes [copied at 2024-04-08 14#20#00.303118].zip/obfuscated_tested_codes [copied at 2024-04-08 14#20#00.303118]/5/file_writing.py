







def write_diamond_pattern(out_file, width):
    diamond = ""
    for i in range(width):
        row = ""
        for j in range(width):
            if abs(width // 2 - i) + abs(width // 2 - j) <= width // 2:
                row += 'x'
            else:
                row += ' '
        diamond += row + '\n'
    return diamond







def last_name_first(in_file, out_file):
    name_list = ""
    with open(in_file, 'r') as f_in:
        for line in f_in:
            names = line.strip().split()
            if len(names) != 2: 
                print(f"'{line.strip()}'does not contain exactly two names.")
                continue 
            first_name, last_name = names 
            name = f"{last_name}, {first_name}\n"
            name_list += name
    with open(out_file, 'w') as f_out:
        f_out.write(name_list)






def add_and_write(in_file, out_file):
    with open(input_file, 'r') as f:
        problems = f.readlines()
    with open(output_file, 'w') as f:
        for problem in problems:
            num1, operator, num2 = problem.split()
            num1 = int(num1)
            num2 = int(num2)
            result = num1 + num2
            f.write(f"{num1} {operator} {num2} = {result}\n")
    




def blah_blah_blah(in_file_name, out_file_name):
    with open(in_file_name, 'r') as in_file:
        lines = in_file.readlines()
    with open(out_file_name, 'w') as out_file:
        for line in lines:
            if len(line) > 20:
                new_line = line[:15] + ', blah blah blah\n'
                out_file.write(new_line)
            else:
                out_file.write(line)
            



def main():
    
    

    
    print('T11 begins:')
    out_file = 'Text files/blank.txt'
    width = 7

    resulting_diamond = write_diamond_pattern(out_file, width)
    with open(out_file, 'w') as my_file:  
        my_file.write(resulting_diamond)
    print()

    
    print('T12 begins:')
    in_file = 'Text files/names.txt'
    out_file = 'Text files/out_file_name.txt'
    last_name_first(in_file, out_file)
    print()

    
    print('T13 begins:')
    input_file = 'Text files/addition.txt'
    output_file = 'Text files/answers.txt'
    add_and_write(input_file, output_file)
    print()

    
    print('T14 begins:')
    in_file_name = 'Text files/long_paragraph.txt'
    out_file_name = 'Text files/shrinked_paragraph.txt'
    blah_blah_blah(in_file_name, out_file_name)


if __name__ == "__main__":
    main()






        


