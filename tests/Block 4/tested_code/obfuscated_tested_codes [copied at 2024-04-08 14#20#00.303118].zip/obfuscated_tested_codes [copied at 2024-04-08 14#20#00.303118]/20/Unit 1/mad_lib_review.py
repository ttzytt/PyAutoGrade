








Noun1 = input("Choose a noun!")  
Noun2 = input("Pick a name, any name!")  
Place1 = input("think of somewhere you'd like to go:D")
Place2 =input("what about another place?")
Animal = input("favorite animal?")
Verb1 = input("think of a verb that end in 'ing'")
Verb2 = input("and a similar one ends in 'ing'")
Name = input("favorite character's name?")
Adj = input("think of an adj?")
Food = input("first food appears in ur mind?")
Noun3 =input("choose another noun!")


print("Studens at PRISMS school are " +  Adj  + " students who like " +  Verb1  +   Noun1  + ".")
print("kids came from all over the world from " +  Place1  + " to " +  Place2  + ".")
print("At leisure time, they play " +  Noun2  + " together.")
print("Sometimes they will see " +  Animal  + " in the backyeard eating grass.")
print("Bob is a " +  Noun3  + ".")
print("He likes " +  Verb2  +".")
print("His favorite food throughout the 4 years spent in PRISMS is cafeteria's " +  Food  + ".")



