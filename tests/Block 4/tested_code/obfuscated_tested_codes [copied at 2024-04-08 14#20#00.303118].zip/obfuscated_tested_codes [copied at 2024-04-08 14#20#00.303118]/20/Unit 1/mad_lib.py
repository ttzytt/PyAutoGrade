


Noun1 = "Dolphin"
Noun2 = "Leslie"
Place1 = "the fishtank"
Place2 = "the toilet"
Animal = "mosquitos"
Verb1 = "hijacking "
Verb2 = "rotating"
Name = "bobby"
Adj = " beautiful "
Food = "fried calamari"
Noun3 = "milky way"

print("Studens at PRISMS school are" + Adj + "students who like " + Verb1 + Noun1 + ".")
print("kids came from all over the world from " + Place1 + " to " + Place2 + ".")
print("At leisure time, they play " + Noun2 + " together.")
print("Sometimes they will see " + Animal + " in the backyeard eating grass.")
print("Bob is a " + Noun3 + ".")
print("He likes " + Verb2 +".")
print("His favorite food throughout the 4 years spent in PRISMS is cafeteria's " + Food + ".")
