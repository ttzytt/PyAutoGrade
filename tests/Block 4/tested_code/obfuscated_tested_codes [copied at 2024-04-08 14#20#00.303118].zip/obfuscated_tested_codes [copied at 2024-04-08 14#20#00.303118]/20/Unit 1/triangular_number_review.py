





n = int(input("choose a positive integer. "))

i = 1
tri = 0
while i <= n:
    tri = tri + i
    i = i + 1

print(f"The traingular number of {n} is {tri}.") 
