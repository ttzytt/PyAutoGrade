



n = input("Input a number: ")



i = 1
product = 1



while i <= int(n):
    product = product * i
    i = i + 1


print(product)
