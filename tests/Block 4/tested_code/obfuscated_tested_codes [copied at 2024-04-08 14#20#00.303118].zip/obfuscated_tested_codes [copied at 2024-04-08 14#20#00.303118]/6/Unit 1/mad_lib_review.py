






ball_game = input('write a ball game')
noun1 = input('write a noun')
number = input('write a number')
noun2 = input('write a noun')
adjective = input('write an adjective')

print('There is a ' + ball_game + ' every Saturday in the town. There is a team called the ' + noun1 + '.')
print('This team is very strong. They can win ' + number + ' more points than the other teams per game.')
print('They are eating ' + noun2 +' before the game. Although it is wierd, it can make them feel ' + adjective + '.')
print('This feeling can help them win the game. So they always win the games.') 
 

