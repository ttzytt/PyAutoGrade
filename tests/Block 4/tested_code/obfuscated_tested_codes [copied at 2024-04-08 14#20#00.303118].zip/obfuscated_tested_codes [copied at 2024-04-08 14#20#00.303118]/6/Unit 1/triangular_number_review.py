








user_number = int(input('Write a number '))











factorial = user_number - 1
count = user_number - 1

while count > 0:
    count = count - 1

    user_number = user_number + factorial
    factorial = factorial - 1
print(user_number)


    
