


user_number = int(input("Please enter a number: ")) 
factorial = user_number 
while user_number > 1:
    factorial = factorial * (user_number - 1) 
    user_number = user_number - 1


print('The factorial of your number is ' + str(factorial))





