





number = int(input('type a number: '))

count = 1 
triangular_number = 0 


while count <= number:
 triangular_number = triangular_number + count
 count = count + 1
 

print()
print('The triangular number of '+ str(number) +' is '+ str(triangular_number) + ' .')

