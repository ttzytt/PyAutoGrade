




user_input = int(input('Type in a Number: '))
factor = 1
result = 1


while factor <= user_input:
    result = result * factor
    factor = factor + 1
    

print('The factorial of ' + str(user_input) + ' is ' + str(result) + '.')




