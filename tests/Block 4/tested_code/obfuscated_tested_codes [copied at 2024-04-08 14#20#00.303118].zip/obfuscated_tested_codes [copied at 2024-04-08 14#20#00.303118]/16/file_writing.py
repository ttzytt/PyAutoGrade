













def write_diamond_pattern(out_file, width):
    for i in range(1, width, 2):
        for j in range(int((width-i) / 2)):
            out_file.write(' ')
        for j in range(i):
            out_file.write('x')
        out_file.write('\n')
        
    for i in range(width, 0, -2): 
        for j in range(int((width-i) / 2)):
            out_file.write(' ')
        for j in range(i):
            out_file.write('x')
        out_file.write('\n')





def last_name_first(in_file, out_file):
    for line in in_file:
        words = line.split()
        out_file.write(words[len(words) - 1] + ', ')
        for i in range(len(words) - 1):
            out_file.write(words[i] + ' ')
        out_file.write('\n')





def add_and_write(in_file, out_file):
    for line in in_file:
        if(line[-1] == '\n'):
            line = line[:-1]
        words = line.split()
        answer = int(words[0]) + int(words[2])
        out_file.write(line + ' = ' + str(answer) + '\n')

        

def blah_blah_blah(in_file_name, out_file_name):
    with (open(in_file_name, 'r') as in_file,
        open(out_file_name, 'w') as out_file):
        for line in in_file:
            if (len(line) > 20):
                out_file.write(line[:15] + ', blah blah blah' + '\n')
            else:
                out_file.write(line)
        
    

    




def main():
    in_file_name = 'Text files/addition.txt'
    out_file_name = 'Text files/writingtestsfile.txt'
    with (open(in_file_name, 'r') as in_file,
        open(out_file_name, 'w') as out_file):
        add_and_write(in_file, out_file)


if __name__ == "__main__":
    main()

    
