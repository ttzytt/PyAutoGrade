


scientist_name = input("Enter a Scientist's Name: ")
adjective = input("Enter an Adjective: ")
plural_noun = input("Enter a Plural Noun: ")
verb = input("Enter a Verb: ")
noun = input("Enter a Noun: ")
liquid = input("Enter a Liquid: ")
type_of_container = input("Enter a Type of Container: ")
number = input("Enter a Number: ")
solid_substance = input("Enter a Solid Substance: ")

substance_ = input("Enter a substance: ")  
heat_source = input("Enter a Heat Source: ")







madlib_story = (' One day, ' + str(scientist_name) + ' was working in their ' + str(adjective) + ' laboratory, ' + ' mixing various ' + str(adjective) + ' in test tubes and Erlenmeyer flasks. ' + 'Suddenly, they had an idea to create a new substance that could ' + str(verb) + ' ' + str(noun) + '.' + ' First, they took 50 mL of ' + str(liquid) + ' and poured it into a ' + str(type_of_container) + '.' + ' Next, they added ' + str(number) + ' grams of ' + str(solid_substance) + ' and stirred the mixture with a ' +str(substance_) + '.' + ' To make the reaction faster, they heated the solution using a ' + str(heat_source) + '.')


print(madlib_story)



