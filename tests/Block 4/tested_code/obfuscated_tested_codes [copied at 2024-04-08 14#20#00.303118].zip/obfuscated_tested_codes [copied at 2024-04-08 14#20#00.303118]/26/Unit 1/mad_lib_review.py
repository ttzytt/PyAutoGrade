







scientist_name = input("Enter a Scientist's Name: ")
adjective = input("Enter an Adjective: ")
plural_noun = input("Enter a Plural Noun: ")
verb = input("Enter a Verb: ")
noun = input("Enter a Noun: ")
liquid = input("Enter a Liquid: ")
type_of_container = input("Enter a Type of Container: ")
number = input("Enter a Number: ")
solid_substance = input("Enter a Solid Substance: ")
object_ = input("Enter an Object: ")  
heat_source = input("Enter a Heat Source: ")





madlib_story = f


print(madlib_story)



