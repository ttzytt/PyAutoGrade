I am SamI am SamSam  I amThat Sam-I-am!That Sam-I-am!I do not likethat Sam-I-am!Do you likegreen eggs and ham?I do not like them,Sam-I-am.I do not likegreen eggs and ham.Would you like themhere or there?I would not lik, blah blah blah
here or there.I would not lik, blah blah blah
anywhere.I do not likegreen eggs and ham.I do not like them,Sam-I-am.Would you like themin a house?Would you like themwith a mouse?I do not like themin a house.I do not like themwith a mouse.I do not like themhere or there.I do not like themanywhere.I do not like g, blah blah blah
I do not like t, blah blah blah
Would you eat themin a box?Would you eat themwith a fox?Not in a box.Not with a fox.Not in a house.Not with a mouse.I would not eat, blah blah blah
I would not eat, blah blah blah
I would not eat, blah blah blah
I do not like t, blah blah blah
Would you? Coul, blah blah blah
In a car?Eat them! Eat them!Here they are.I would not,could not,in a car.You may like them.You will see.You may like themin a tree!I would not, co, blah blah blah
Not in a car! Y, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like g, blah blah blah
I do not like t, blah blah blah
A train! A train!A train! A train!Could you, woul, blah blah blah
on a train?Not on a train!, blah blah blah
Not in a car! S, blah blah blah
I would not, co, blah blah blah
I could not, wo, blah blah blah
I will not eat , blah blah blah
I will not eat , blah blah blah
i will not eat , blah blah blah
I will not eat , blah blah blah
I do not eat gr, blah blah blah
I do not like t, blah blah blah
Say!In the dark?Here in the dark!Would you, coul, blah blah blah
I would not, co, blah blah blah
in the dark.Would you, coul, blah blah blah
in the rain?I would not, co, blah blah blah
Not in the dark, blah blah blah
Not in a car. N, blah blah blah
I do not like t, blah blah blah
Not in a house., blah blah blah
Not with a mous, blah blah blah
I will not eat , blah blah blah
I do not like t, blah blah blah
You do not likegreen eggs and ham?I do notlike them,Sam-I-am.Could you, would youwith a goat?I would not,could not,with a goat!Would you, coul, blah blah blah
on a boat?I could not, wo, blah blah blah
I will not, wil, blah blah blah
I will not eat , blah blah blah
I will not eat , blah blah blah
Not in the dark, blah blah blah
Not in a car! Y, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I will not eat , blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not likegreen eggsand ham!I do not like them,Sam-I-am.You do not like, blah blah blah
So you say.Try them! Try them!And you may.Try them and yo, blah blah blah
Sam!If you will let, blah blah blah
I will try them.You will see.Say!I like green eg, blah blah blah
I do! I like th, blah blah blah
And I would eat, blah blah blah
And I would eat, blah blah blah
And I will eat , blah blah blah
And in the dark, blah blah blah
And in a car. A, blah blah blah
They are so goo, blah blah blah
So I will eat t, blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
Say! I will eat, blah blah blah
I do so likegreen eggs and ham!Thank you!Thank you,Sam-I-am!