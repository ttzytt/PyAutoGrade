I would not lik, blah blah blah
I would not lik, blah blah blah
I do not like g, blah blah blah
I do not like t, blah blah blah
I would not eat, blah blah blah
I would not eat, blah blah blah
I would not eat, blah blah blah
I do not like t, blah blah blah
Would you? Coul, blah blah blah
I would not, co, blah blah blah
Not in a car! Y, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like g, blah blah blah
I do not like t, blah blah blah
Could you, woul, blah blah blah
Not on a train!, blah blah blah
Not in a car! S, blah blah blah
I would not, co, blah blah blah
I could not, wo, blah blah blah
I will not eat , blah blah blah
I will not eat , blah blah blah
i will not eat , blah blah blah
I will not eat , blah blah blah
I do not eat gr, blah blah blah
I do not like t, blah blah blah
Would you, coul, blah blah blah
I would not, co, blah blah blah
Would you, coul, blah blah blah
I would not, co, blah blah blah
Not in the dark, blah blah blah
Not in a car. N, blah blah blah
I do not like t, blah blah blah
Not in a house., blah blah blah
Not with a mous, blah blah blah
I will not eat , blah blah blah
I do not like t, blah blah blah
Would you, coul, blah blah blah
I could not, wo, blah blah blah
I will not, wil, blah blah blah
I will not eat , blah blah blah
I will not eat , blah blah blah
Not in the dark, blah blah blah
Not in a car! Y, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I will not eat , blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
I do not like t, blah blah blah
You do not like, blah blah blah
Try them and yo, blah blah blah
If you will let, blah blah blah
I like green eg, blah blah blah
I do! I like th, blah blah blah
And I would eat, blah blah blah
And I would eat, blah blah blah
And I will eat , blah blah blah
And in the dark, blah blah blah
And in a car. A, blah blah blah
They are so goo, blah blah blah
So I will eat t, blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
And I will eat , blah blah blah
Say! I will eat, blah blah blah
Say! I will eat, blah blah blah
