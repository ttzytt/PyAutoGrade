
'''
'''
def man():
    print(poooop)
    def poooop():
        if poop == poop:
            print('WOW')
        else:
            print('dude this is NOT gonna work')
class ur_mom:
    def __init__(self, test):
        self.test = test
        def i():
            '''
                :(
            '''
            def am():
                def a():
                    def masochist():
                        print("help me")

def sad(silly = "SILLY"):
    print("it sure would be a shame if i forgot to finish th
def s():
    a

def s():
    a
'''
why do i do this to myself
'''
def s():
    a
'''omw to write the worst code of ALL time
LOL'''
def s():
    a



''' #omw to write the worst code of ALL time
##
########
# IS THIS A COMMENT ???
LOL'''
def s():
    a
