

"""
Teacher comments:
• This file shouldn't have reviewer comments in it when you're done.
• I really like your prompts!
• Variable names must follow proper style.
• Needs comments!!!
• Comments (even the ones above) must start with spaces.
• Too many blank lines. They should be used to divide the code into
logical sections.

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""

noun_1 = input('Choose a noun: ')  
noun_2 = input('Choose another one!: ')

print("Let's change things up a bit :) ")  

verb = input("This time, choose a verb that ends in 'ing': ")
adjective_1 = input('Adjective? ')  
adjective_1 = input('You can do better... choose something else :( ')
adjective_2 = input('Another one: ')
emotion = input('How are feeling today? (noun) ')


print('Great job! Now, enjoy a story...')
print(noun_1 + ' loves ' + verb + ' at Texas Outback Steakhouse.')
print('Ever since ' + verb + ' at Outback Steakhouse, ' + noun_1 + ' grew a ' + adjective_1 + ', ' + adjective_2 + ' beard.')
print('Unfortunately, because of ' + noun_1 + "'s" + " violation of the customers' " + noun_2 + ' code, he was fired, to his ' + emotion + '.')





