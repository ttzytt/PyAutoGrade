

'''
function for...
hihiihihi
uyfuyfuyf
'''
def this_is_testing():
    Return('hi')

print('Omg did u not put a space???')
