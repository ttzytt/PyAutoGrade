
'''
function for...
hihiihihi
uyfuyfuyf
'''







def this_is_testing():
    Return('hi')
print('Omg did u not put a space???')


ytrytrydjdkhlyflu6toritreafg,jekjh2yg2ri3giygfigiyfgyfy2fgi2fug2dieyfgwieyfweifweygweiygwiyegiwe
