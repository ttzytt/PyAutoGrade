def a():
    print(1)

def b():
    print(2)
    print(3)

def c():
    print(2)
    print(3)
    print(4)

def d():
    print(2)
