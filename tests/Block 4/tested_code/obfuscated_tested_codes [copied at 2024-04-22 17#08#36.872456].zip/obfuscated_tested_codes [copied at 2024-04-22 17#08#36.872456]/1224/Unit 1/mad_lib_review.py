

print ('A Mad Lib by Sam Kemp') 
noun1 = input ('Noun: ')
verb1 = input ('Verb (Past Tense): ')   
noun2 = input ('Noun: ')
adjective1 = input ('Adjective (not ending in "ily" or "ing"): ')
verb2 = input ('Verb: ')
noun3 = input ('Noun (Name): ')
adjective2 = input ('Adjective (not ending in "ily"): ')
noun4 = input ('Noun (Plural): ')
adjective3 = input ('Adjective: ')
noun5 = input ('Noun (Plural): ')

print ('There was a' + ' ' + noun1 + ' ' + 'named Bob who' + ' ' + verb1 + ' ' + 'to their job at Walmart every day. At work, Bob saw a' + ' ' + noun2 + ' ' + 'that was very' + ' ' + adjective1 + '. ' + 'A guy that kind of looked like' + ' ' + noun3 + ' ' + 'asked if this store sold' + ' ' + adjective2 + ' ' + noun4 + '. '+ 'Bob told them no and that they only sold' + ' ' + adjective3 + ' ' + noun5 + '.' + ' ' + 'The guy walked away and Bob clocked out of his shift and went home. The end.')



