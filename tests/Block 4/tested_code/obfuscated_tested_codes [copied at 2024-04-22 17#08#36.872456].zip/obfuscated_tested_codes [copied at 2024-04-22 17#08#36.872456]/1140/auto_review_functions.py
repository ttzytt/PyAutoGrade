


'''
The purpose of these tasks is to automate some parts of code review.
Note that despite the ".py" extension, Python files are just plain text,
so they can be read in just like ".txt" files.

Follow the same instructions as for the other mini-tasks. For these tasks, feel free to read in
the whole code file at once using readlines(). If you have a list my_list, you can insert new
items into the list using my_list.insert(index, element). For example, if my_list is
[0,1,2,3], then after calling my_list.insert(2,77), my_list will be [0,1,77,2,3].
Once you have a list of lines-of-code, you can use this to insert new lines
of code into the list.

'''




def comments_for_functions(in_file, out_file):
