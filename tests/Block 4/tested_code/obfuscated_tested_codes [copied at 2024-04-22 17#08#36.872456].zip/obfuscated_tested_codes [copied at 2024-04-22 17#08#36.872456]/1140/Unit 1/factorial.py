



number = int(input('Enter an integer n: '))

count = 0

factorial = 1


while count < number:
    count = count + 1
    factorial = factorial * count
    

print('n factorial is equal to ' + str(factorial))

