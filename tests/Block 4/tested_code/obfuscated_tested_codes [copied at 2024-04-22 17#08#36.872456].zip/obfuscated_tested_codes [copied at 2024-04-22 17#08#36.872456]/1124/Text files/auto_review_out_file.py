

def bkah():
    return 3


def fdnios():
    return 4

def hsdfngjk():
    return 5
definition

blah
blah
weird code stuff
dont know what to write


