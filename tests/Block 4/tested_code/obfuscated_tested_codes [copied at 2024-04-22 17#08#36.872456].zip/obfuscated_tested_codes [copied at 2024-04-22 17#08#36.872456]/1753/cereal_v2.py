


fruit_loops = {'red' : 6, 'blue' : 5, 'yellow' : 7, 'orange' : 7, 'purple' : 4, 'green' : 6}

user_input = input('What color combination would you like'
                ' example response: red orange yellow), or enter quit: ')

while user_input.lower() != 'quit':
    split = user_input.lower().split()
    
    if split[0].lower() == 'floor':
        if split
        
        
        
        


    
    else:
        total = 0
        for key in keys:
            total = total + fruit_loop[key]

        print('The total amount of fruit loops is ' + str(total))
        print()

    
        user_input = input('What color combination would you like'
                       ' example response: red orange yellow), or enter quit: ')








