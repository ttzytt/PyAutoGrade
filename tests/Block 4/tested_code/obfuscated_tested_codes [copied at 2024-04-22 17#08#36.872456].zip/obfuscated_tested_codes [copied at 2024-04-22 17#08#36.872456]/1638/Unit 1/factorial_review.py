



integer = input(' Tell me a random integer ')






integer = int(float(integer))
number = 1
result = 1



while number <= integer:
    result = result * number
    number = number + 1


print(result)
    
