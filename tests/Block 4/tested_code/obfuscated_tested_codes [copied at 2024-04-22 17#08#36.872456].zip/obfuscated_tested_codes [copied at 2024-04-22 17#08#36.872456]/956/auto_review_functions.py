


'''
Make sure each function has a comment that explains what it does.
Any time there is a function definition in the file without a comment on the line before it,
Add a line of code that says
'
    inputs:
        in_file
        out_file    A file that is open for reading.
'''

def comments_for_functions(in_file, out_file):
