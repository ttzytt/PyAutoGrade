

"""
Teacher comments:
• Variable names must follow proper style. noun1 should be noun_1, etc.
• Overall formatting looks good.
• Unnecessary use of str() and \ make the code look a bit more complicated.
• Good first try at comments, see my suggestions below.

If I make comments in your code,
I will use ### to make them stand out.

Do not remove any of my comments.
"""






place = str(input("Place: "))
name = str(input("Name: "))
noun_1 = str(input("Noun 1: "))
verb = str(input("Verb: "))
adjective_1 = str(input("Adjective 1: "))
noun_2 = str(input("Noun 2: "))
adjective_2 = str(input("Adjective 2: "))









print("Today I went to " + place + " to see my friend " + name + ". " + name \
      + " had recently bought a " + noun_1 + " to " + verb \
      + " their cat with. I watched them do it at " + place + ", and now I am very very " \
      + adjective_1 + ". " + name + " has inspired me. Now I will obtain a " \
      + noun_2 + " and get up to some " + adjective_2 + " business.")
