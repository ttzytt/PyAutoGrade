



list1 = [1,2, 3,4,5, 6]

x= 1+2 * 3+4 /19


def tumadre(input1, input2):
    input1 = 7
    '''
    HELLO
    '''
    def tupadre(input1, input2):
        for i in range(1,4):
            input2[i] += 1

        return input2[input1]

    y = tupadre(input1, list1)

    return input2 + y

mi =tumadre(5, 100000000000000)

    

    
